<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 2</title>
</head>
<body>
    <h1>This is PAGE 2</h1>
    <a href="/page1">go to page 1</a>
    <a href="/page2">go to page 2</a>
    <a href="/page3">go to page 3</a>
</body>
</html><?php /**PATH C:\Users\myfin\OneDrive\Documents\laravel\laravel-api-myquiz\resources\views/page2.blade.php ENDPATH**/ ?>